# Simple Streamlit app placeholder
import streamlit as st
st.title('Decision Tree Demo')
